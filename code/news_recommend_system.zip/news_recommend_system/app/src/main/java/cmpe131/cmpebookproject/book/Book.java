package cmpe131.cmpebookproject.book;

import android.content.Context;
import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.TextView;

import java.io.Serializable;

import cmpe131.cmpebookproject.R;
import cmpe131.cmpebookproject.Util;
import cmpe131.cmpebookproject.activity.BookInfoActivity;
import cmpe131.cmpebookproject.Listable;

public class Book implements Parcelable, Listable, Serializable {

    private static final long serialVersionUID = Util.generateSerialUID("book_v1");
    private String title;
    private String author;
    private String isbn;
    private float rating;
    private String publisher;
    private int numPages;
    private int yearPublished;
    private Genre genre;
    private transient float similarityIndex = 0f; // 用于搜索,瞬态意味着在序列化期间将不会保存

    public Book(String title, String author, String isbn, float rating, String publisher,  int numPages, int yearPublished, Genre genre) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.rating = rating;
        this.publisher = publisher;
        this.numPages = numPages;
        this.yearPublished = yearPublished;
        this.genre = genre;
    }

    public String getTitle() {return title;}
    public void setTitle(String title) {this.title = title;}
    public String getAuthor() {return author;}
    public void setAuthor(String author) {this.author = author;}
    public String getPublisher() {return publisher;}
    public void setPublisher(String publisher) {this.publisher = publisher;}
    public int getYearPublished() {return yearPublished;}
    public void setYearPublished(int yearPublished) {this.yearPublished = yearPublished;}
    public String getIsbn() {return isbn;}
    public void setIsbn(String isbn) {this.isbn = isbn;}
    public Genre getGenre() {return genre;}
    public void setGenre(Genre genre) {this.genre = genre;}
    public int getNumPages() {return numPages;}
    public void setNumPages(int numPages) {this.numPages = numPages;}
    public float getRating() {return rating;}
    public void setSimilarityIndex(float similarityIndex) {this.similarityIndex = similarityIndex;}
    public float getSimilarityIndex() {return similarityIndex;}

    @Override
    public String toString() {
        return title;
    }

    @Override
    public boolean equals(Object obj) {     //判断传入的对象是否和this所指的相同
        if (!(obj instanceof Book))  //java中的一个双目运算符，用来测试一个对象是否是Book类的实例
            return false;
        Book other = (Book)obj; //如果是Book类的实例，进行转换

        boolean sameTitle = this.title.equals(other.title);
        boolean sameAuthor = this.author.equals(other.author);
        boolean samePublisher = this.publisher.equals(other.publisher);
        boolean sameYearPublished = this.yearPublished == other.yearPublished;
        boolean sameIsbn = this.isbn.equals(other.isbn);
        boolean sameGenre = this.genre.equals(other.genre);
        boolean sameNumPages = this.numPages == other.numPages;
        boolean sameRating = this.rating == other.rating;
        return sameTitle && sameAuthor && samePublisher && sameYearPublished && sameIsbn && sameGenre && sameNumPages && sameRating;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {   //parcel包装了我们需要传输的数据，然后在Binder中传输，用于跨进程传输数据。
        dest.writeString(title);
        dest.writeString(author);
        dest.writeString(isbn);
        dest.writeFloat(rating);
        dest.writeString(publisher);
        dest.writeInt(numPages);
        dest.writeInt(yearPublished);
        dest.writeString(genre.toString());
        //将序列化之后的数据写入一个共享内存中
    }

    public Book(Parcel in)
        {
            title = in.readString();
            author = in.readString();
            isbn = in.readString();
            rating = in.readFloat();
            publisher = in.readString();
            numPages = in.readInt();
            yearPublished = in.readInt();
            genre = Genre.getEnum(in.readString());
            //他进程通过Parcel可以从这块共享内存读出字节流，并反序列化成对象
        }

    public static final Parcelable.Creator<Book> CREATOR
                = new Parcelable.Creator<Book>() {
        public Book createFromParcel(Parcel in) {
            return new Book(in);
            }
       //返回反序列化后生成的对象
        public Book[] newArray(int size) {
                return new Book[size];
            }
        };

    @Override
    public void populateListView(View listView) {
        TextView title = listView.findViewById(R.id.listitem_book_label_title);
        title.setText(this.title);
        TextView author = listView.findViewById(R.id.listitem_book_label_author);
        author.setText(this.author);
        TextView yearGenre = listView.findViewById(R.id.listitem_book_label_yearANDgenre);
        yearGenre.setText(this.yearPublished + " - " + this.genre);
        TextView pageCount = listView.findViewById(R.id.listitem_book_label_pcount);
        pageCount.setText(this.numPages + " words");
        TextView rating = listView.findViewById(R.id.listitem_book_label_rating);
        rating.setText(this.rating + "/5");
    }     //显示图书的相关信息

    @Nullable
    @Override
    public Intent getDisplayIntent(Context context) {
        Intent displayIntent = new Intent(context, BookInfoActivity.class);//intent用于协助应用间的交互和通讯
        displayIntent.putExtra(Util.INTENT_DATA_BOOK, (Parcelable)this);
        //设置key-value数据，然后进行传输
        return displayIntent;
    }

    @Override
    public int getListViewLayoutRes() {
        return R.layout.listitem_book;
    }
}


