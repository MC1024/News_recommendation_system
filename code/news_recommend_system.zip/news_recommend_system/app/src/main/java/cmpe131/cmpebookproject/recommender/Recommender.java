package cmpe131.cmpebookproject.recommender;

import android.os.Build;
import android.support.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;

import cmpe131.cmpebookproject.book.Book;
import cmpe131.cmpebookproject.user.User;

/**
 * Recommender finds books in the database that match the Users preferences
 */
public class Recommender {   //执行推荐的过程

    private User currentUser;     //当前用户
    private ArrayList<Book> database;   //书籍列表
    private ArrayList<Book> filteredBooks;  //筛选后的列表
    private PriorityQueue<Book> recommendedBooks;
    private ArrayList<Book> relevantOrderedBooks;
    private int numberOfBooksRecommended;

    /**
     * Constructor for Recommender
     * @param currentUser
     * @param database
     * @param numberOfBooksRecommended
     */
    public Recommender(User currentUser, ArrayList<Book> database, int numberOfBooksRecommended){
        this.currentUser = currentUser;
        this.database = database;
        this.filteredBooks = new ArrayList<>();
        //! need to add getAverageRating method in Book
        //this is a min heap priority queue ordered by rating
        this.recommendedBooks = new PriorityQueue<Book>(numberOfBooksRecommended + 1, new Comparator<Book>()
                                {
                                @Override
                                public int compare(Book book1, Book book2) {
                                   return (int)(book1.getRating() - book2.getRating()); }
                                });
        this.relevantOrderedBooks = new ArrayList<Book>();
        this.numberOfBooksRecommended = numberOfBooksRecommended;
    }

    /**
         返回与用户首选项匹配的书籍的数组列表，这些书籍按照最高等级松散排序
     * @return - books recommended to the user as an ArrayList<Book>
     */
    public ArrayList<Book> produceRecommendedBooks(){     //返回推荐列表结果
        filterBooks();
        makeRecommendedBookList();
        putRecommendedBooksInRelevantOrder();

        return relevantOrderedBooks;
    }

    /**
     *    从数据库中查找与用户首选项匹配的书籍，并将它们筛选到名为“筛选书籍”的数组列表中
     */
    //! Only filters by genre as of now
    public void filterBooks(){
        //filter in books that contain a liked genre of the user
        for(Book book : database){     //从数据库中筛选
            if(currentUser.getLikedGenres().contains(book.getGenre())) {
                filteredBooks.add(book);
            }
        }
         //应该有更多的方法去过滤
        //!SHOULD ADD MORE Ways to filter here by taking into account only the users profile
    }

    /**
         将排名靠前的元素按相反的堆顺序排列(从最小到最大排列)。该算法使用常数内存，即推荐的书籍数量。
     */
    public void makeRecommendedBookList()
    {
        for(Book book : filteredBooks){
            recommendedBooks.add(book);
            if(recommendedBooks.size() > numberOfBooksRecommended){
                recommendedBooks.poll();
            }
        }

    }

    /**
         对图书进行重新排序，使其从最高到最低排序，并将元素存储到数组列表<图书>相关有序的图书中
     */
    public void putRecommendedBooksInRelevantOrder(){
        PriorityQueue<Book> orderedRecommended = new PriorityQueue<Book>(numberOfBooksRecommended, new Comparator<Book>()
            {
                @Override
                public int compare(Book book1, Book book2) {
                return (int)(book2.getRating() - book1.getRating()); }
            });

        orderedRecommended.addAll(recommendedBooks);

        relevantOrderedBooks.addAll(orderedRecommended);
    }

    /**
     * Gets the currentUser
     * @return - currentUser
     */
    public User getCurrentUser() {
        return currentUser;
    }
    /**
     * Sets a new currentUser (probably shouldn't be used)
     * @param currentUser - new user to be currentUser
     */
    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }
    /**
     * Gets the database of books
     * @return - the database of books
     */
    public ArrayList<Book> getDatabase() {
        return database;
    }
    /**
     * Sets a new databse with specified ArrayList (probably shouldn't be used)
     * @param database - new database to be set to database
     */
    public void setDatabase(ArrayList<Book> database) {
        this.database = database;
    }
    /**
     * Gets the filtered books array list
     * @return - the filtered books (unordered)
     */
    public ArrayList<Book> getFilteredBooks() {
        return filteredBooks;
    }
    /**
     * Sets new filteredBooks with specified ArrayList (probably shouldn't be used)
     * @param filteredBooks - new filtered books to be set to filteredBooks
     */
    public void setFilteredBooks(ArrayList<Book> filteredBooks) {
        this.filteredBooks = filteredBooks;
    }
    /**
     * Gets the recommendedBooks
     * @return - the recommended books ordered by rating (highest to lowest)
     */
    public PriorityQueue<Book> getRecommendedBooks() {
        return recommendedBooks;
    }
    /**
     * Sets new recommendedBooks with specified ArrayList (probably shouldn't be used)
     * @param recommendedBooks - new recommended books to be set to recommendedBooks
     */
    public void setRecommendedBooks(PriorityQueue<Book> recommendedBooks) {
        this.recommendedBooks = recommendedBooks;
    }
    /**
     * Gets the max number of books to be recommended to the user
     * @return - the number of books that should be recommended to the user
     */
    public int getNumberOfBooksRecommended() {
        return numberOfBooksRecommended;
    }
    /**
     * Sets the max number of books to be recommended with specified int value
     * @param numberOfBooksRecommended - new number of books to be recommended to numberOfBooksRecommended
     */
    public void setNumberOfBooksRecommended(int numberOfBooksRecommended) {
        this.numberOfBooksRecommended = numberOfBooksRecommended;
    }
}


