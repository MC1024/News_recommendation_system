package cmpe131.cmpebookproject;

import android.content.Context;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import java.util.ArrayList;

import static android.view.View.FOCUS_DOWN;

/** This is a whole lot of work just to make the virtual keyboard close when you press enter/done **/
//当你按下enter/done键时，要关闭虚拟键盘需要做大量的工作
public class FieldFocusTools {

    public static void clearFocus(View v) {
        InputMethodManager imm = (InputMethodManager)v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    public static void passFocus(View v) {
        View nextView = v.focusSearch(FOCUS_DOWN);
        if (nextView != null) {
            nextView.requestFocus();
        }
        else
            clearFocus(v);
    }

    public static void setOnKeyListener_clearFocusOnFinish(EditText field) {
        field.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View view, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_ENTER) {
                    clearFocus(view);
                    return true;
                } else {
                    return false;
                }
            }
        });
        System.out.println("Applied FIELD_CLEAR_FOCUS_ON_FINISH KeyListener to field " + Util.getIdString(field));
    }

    public static void setOnKeyListener_passFocusOnFinish(EditText field) {
        field.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View view, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_ENTER) {
                    passFocus(view);
                    return true;
                } else {
                    return false;
                }
            }
        });
        System.out.println("Applied FIELD_PASS_FOCUS_ON_FINISH KeyListener to field " + Util.getIdString(field));
    }

    public static void setAllFieldsClearFocusOnFinish (ViewGroup vg) {
        // could be faster by instead applying KeyListeners while looping to get all fields
        // but this is much more readable and easier to debug
        ArrayList<EditText> allFields = getAllFields(vg, false);
        for (EditText field : allFields)
            setOnKeyListener_clearFocusOnFinish(field);
        //更加易读和调试
    }

    public static void setAllFieldsPassFocusOnFinish (ViewGroup vg) {
        // could be faster by instead applying KeyListeners while looping to get all fields
        // but this is much more readable and easier to debug
        ArrayList<EditText> allFields = getAllFields(vg, false);
        for (EditText field : allFields)
            setOnKeyListener_passFocusOnFinish(field);
    }



    // returns a list of all fields within this ViewGroup, INCLUDING those within all sub-ViewGroups
    private static ArrayList<EditText> getAllFields (ViewGroup vg, boolean debug) {
        ArrayList<EditText> fields = new ArrayList<>();
        /*DEBUG*/ if (debug) System.out.println("Finding all fields...");

        for (int i = 0; i < vg.getChildCount(); i++) {
            View v = vg.getChildAt(i);
            if (v instanceof EditText) {
                /*DEBUG*/ if(debug) System.out.println("Within ViewGroup " + Util.getIdString(vg) + " Found EditText " + Util.getIdString(v));
                fields.add((EditText)v);
            }
            else if (v instanceof ViewGroup) {
                /*DEBUG*/ if(debug) System.out.println("Within ViewGroup " + Util.getIdString(vg) + " Found child ViewGroup " + Util.getIdString(v) + " (child count " + ((ViewGroup) v).getChildCount() + ")");
                if (((ViewGroup) v).getChildCount()!= 0)
                    fields.addAll(getAllFields((ViewGroup)v, debug));
            }
        }

        /*DEBUG*/ if(debug) System.out.println("All fields found.");
        return fields;
    }

}
