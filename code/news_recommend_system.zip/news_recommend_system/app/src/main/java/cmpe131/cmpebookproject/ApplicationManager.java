package cmpe131.cmpebookproject;

import android.app.Application;
import android.content.Context;
import android.content.Intent;

import cmpe131.cmpebookproject.activity.LoginActivity;
import cmpe131.cmpebookproject.database.DbHelper;
import cmpe131.cmpebookproject.database.UserReadWriteException;
import cmpe131.cmpebookproject.user.User;

public class ApplicationManager extends Application {
    /**
     * Keeps a reference of the application context and active user
     * 保留应用程序上下文和活动用户的引用
     *
     */
    private static Context sContext;   //应用程序上下文？
    private static User sActiveUser;   //活动用户

    @Override
    public void onCreate() {
        super.onCreate();
        sContext = getApplicationContext();
    }

    /**
     * Returns the application context.
     *
     * @return application context
     */
    public static Context getContext() {
        return sContext;
    }

    /**
     * Returns the active user.返回活动用户
     *
     * @throws cmpe131.cmpebookproject.database.UserReadWriteException if there is no active user如果没有活动用户
     * @return application context   返回应用程序上下文
     */
    public static User getActiveUser() {
        if (sActiveUser == null)
            throw new UserReadWriteException("WARNING: ACTIVE USER IS NULL. WILL CAUSE FATAL ERRORS.");
        return sActiveUser;
    }

    /**
     *
     * 尝试基于给定的登录凭据设置活动用户
     *
     * @return true if the login was successful, false if not  返回是否登录成功
     */
    public static boolean login(String username, String password) {
        sActiveUser = DbHelper.getInstance(sContext).getUser(username, password);
        return sActiveUser != null;
    }

    /**
     * 注销当前活动用户，转到登录活动，并清除活动链
     * 本质上重置应用程序
     */
    public static void logout() {
        sActiveUser = null;
        Intent logoutIntent = new Intent(sContext, LoginActivity.class);
        logoutIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        sContext.startActivity(logoutIntent);
    }



}
