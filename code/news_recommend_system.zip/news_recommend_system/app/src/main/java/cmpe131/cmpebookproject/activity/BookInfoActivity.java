package cmpe131.cmpebookproject.activity;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;

import cmpe131.cmpebookproject.UserListAdapter;
import cmpe131.cmpebookproject.R;
import cmpe131.cmpebookproject.Util;
import cmpe131.cmpebookproject.book.Book;
import cmpe131.cmpebookproject.book.BookList;
import cmpe131.cmpebookproject.database.DbHelper;

public class BookInfoActivity extends UserActivityBase {  //描述图书信息

    Book activeBook;

    TextView title;
    TextView author;
    TextView pubAndYear;
    TextView isbn;
    TextView genreAndPcount;
    TextView rating;
    Button addToListButton;

    AlertDialog addToListDialog;       //定义一个对话框

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookinfo);

        activeBook = getIntent().getParcelableExtra(Util.INTENT_DATA_BOOK);
       //接收通过intent传输过来的对象，取出intent中包含的数据

        title = findViewById(R.id.bookinfo_label_title);
        author = findViewById(R.id.bookinfo_label_author);
        pubAndYear = findViewById(R.id.bookinfo_label_publisherANDyear);
        isbn = findViewById(R.id.bookinfo_label_isbn);
        genreAndPcount = findViewById(R.id.bookinfo_label_genreANDpagecount);
        rating = findViewById(R.id.bookinfo_label_rating);
        addToListButton = findViewById(R.id.bookinfo_button_addtolist);

        title.setText(activeBook.getTitle());
        author.setText(activeBook.getAuthor());
        pubAndYear.setText("create in " + activeBook.getYearPublished() + " by " + activeBook.getPublisher());
        isbn.setText("news id: " + activeBook.getIsbn());
        genreAndPcount.setText(activeBook.getGenre().toString() + " - " + activeBook.getNumPages() + " words");
        rating.setText("Average rating: " + activeBook.getRating() + "/5");
              //显示图书的相关信息

        DialogInterface.OnClickListener addToList = new DialogInterface.OnClickListener() { //单击对话框上的项目时，用于允许对话框的创建者运行一些代码的界面
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (activeUser.appendCustomList(activeBook,which)) {
                    System.out.println("Added " + activeBook + " to list " + activeUser.getCustomLists().get(which));
                    Util.shortToast(getApplicationContext(), "Added!");
                    DbHelper.getInstance(getApplicationContext()).appendUser(activeUser);
                }
                else
                    Util.shortToast(getApplicationContext(), "That list already contains this news");
            }
        };
        //对话框采用builder模式进行设计，将对话框的创建和表现显示分离。
        addToListDialog = new AlertDialog.Builder(this)  //设置对话框
                .setTitle(addToListButton.getText())  //构造对话框的标题
                .setNegativeButton("Cancel", null)     //设置负面按钮
                .setAdapter(new UserListAdapter(this,R.layout.support_simple_spinner_dropdown_item,activeUser.getCustomLists(), activeBook),addToList)
                .create();//构建对话框
        addToListButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (activeUser.getCustomLists().size() == 0)
                    Util.shortToast(getApplicationContext(), "You don't have any lists to add this to");
                    //封装后的toast，可以缩短代码长度。使用前需要设置工具类（util）
                else
                    addToListDialog.show();  //显示对话框
            }
        });

    }
}
